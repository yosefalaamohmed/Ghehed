// متغيرات عامة
let currentSection = 'dashboard';
let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
let habits = JSON.parse(localStorage.getItem('habits')) || [];
let projects = JSON.parse(localStorage.getItem('projects')) || [];
let notes = JSON.parse(localStorage.getItem('notes')) || [];
let settings = JSON.parse(localStorage.getItem('settings')) || {
    theme: 'light',
    notifications: true,
    pomodoroTime: 25,
    shortBreak: 5,
    longBreak: 15
};

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    // إخفاء شاشة التحميل
    setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
        document.querySelector('.app-container').classList.add('loaded');
    }, 1500);

    // تطبيق الثيم المحفوظ
    applyTheme(settings.theme);

    // إعداد مستمعي الأحداث
    setupEventListeners();

    // تحديث الإحصائيات
    updateDashboardStats();

    // تحديث المهام الحديثة
    updateRecentTasks();

    // إنشاء الرسم البياني
    createWeeklyChart();

    // تحديث الإشعارات
    updateNotifications();
}

function setupEventListeners() {
    // التنقل في الشريط الجانبي
    const menuItems = document.querySelectorAll('.menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', () => {
            const section = item.dataset.section;
            switchSection(section);
            
            // تحديث العنصر النشط
            menuItems.forEach(mi => mi.classList.remove('active'));
            item.classList.add('active');
            
            // تحديث عنوان الصفحة
            const pageTitle = item.querySelector('span').textContent;
            document.getElementById('page-title').textContent = pageTitle;
        });
    });

    // تبديل الشريط الجانبي
    const sidebarToggle = document.getElementById('sidebar-toggle');
    const mobileMenuToggle = document.getElementById('mobile-menu-toggle');
    const sidebar = document.getElementById('sidebar');

    sidebarToggle?.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
    });

    mobileMenuToggle?.addEventListener('click', () => {
        sidebar.classList.toggle('show');
    });

    // تبديل الثيم
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle?.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        applyTheme(newTheme);
        settings.theme = newTheme;
        saveSettings();
    });

    // الإشعارات
    const notificationBtn = document.getElementById('notification-btn');
    const notificationDropdown = document.getElementById('notification-dropdown');

    notificationBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        notificationDropdown.classList.toggle('show');
    });

    document.addEventListener('click', () => {
        notificationDropdown?.classList.remove('show');
    });

    // البحث العام
    const globalSearch = document.getElementById('global-search');
    globalSearch?.addEventListener('input', (e) => {
        performGlobalSearch(e.target.value);
    });

    // الإجراءات السريعة
    const actionButtons = document.querySelectorAll('.action-btn');
    actionButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const action = btn.dataset.action;
            performQuickAction(action);
        });
    });

    // إدارة المهام
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskModal = document.getElementById('task-modal');
    const modalOverlay = document.getElementById('modal-overlay');
    const modalClose = document.getElementById('modal-close');
    const cancelTask = document.getElementById('cancel-task');
    const taskForm = document.getElementById('task-form');

    addTaskBtn?.addEventListener('click', () => {
        openTaskModal();
    });

    modalClose?.addEventListener('click', () => {
        closeTaskModal();
    });

    cancelTask?.addEventListener('click', () => {
        closeTaskModal();
    });

    modalOverlay?.addEventListener('click', (e) => {
        if (e.target === modalOverlay) {
            closeTaskModal();
        }
    });

    taskForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        saveTask();
    });

    // فلاتر المهام
    const filterButtons = document.querySelectorAll('.filter-btn');
    filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            filterButtons.forEach(fb => fb.classList.remove('active'));
            btn.classList.add('active');
            filterTasks(btn.dataset.filter);
        });
    });

    // ترتيب المهام
    const sortTasks = document.getElementById('sort-tasks');
    sortTasks?.addEventListener('change', (e) => {
        sortTasksBy(e.target.value);
    });
}

function switchSection(sectionName) {
    // إخفاء جميع الأقسام
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });

    // إظهار القسم المحدد
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.add('active');
        currentSection = sectionName;
    }

    // تحديث المحتوى حسب القسم
    switch(sectionName) {
        case 'dashboard':
            updateDashboardStats();
            updateRecentTasks();
            break;
        case 'tasks':
            renderTasks();
            break;
        case 'timer':
            initializeTimer();
            break;
        case 'habits':
            renderHabits();
            break;
        case 'projects':
            renderProjects();
            break;
        case 'statistics':
            renderStatistics();
            break;
        case 'notes':
            renderNotes();
            break;
    }
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const themeIcon = document.querySelector('#theme-toggle i');
    if (themeIcon) {
        themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

function updateDashboardStats() {
    const today = new Date().toDateString();
    const todayTasks = tasks.filter(task => 
        new Date(task.createdAt).toDateString() === today
    );
    
    const completedTasks = todayTasks.filter(task => task.completed).length;
    const focusTime = getTodayFocusTime();
    const completedHabits = getTodayCompletedHabits();
    const productivityScore = calculateProductivityScore();

    document.getElementById('tasks-completed').textContent = completedTasks;
    document.getElementById('time-focused').textContent = focusTime;
    document.getElementById('habits-done').textContent = completedHabits;
    document.getElementById('productivity-score').textContent = `${productivityScore}%`;
}

function updateRecentTasks() {
    const recentTasksList = document.getElementById('recent-tasks-list');
    if (!recentTasksList) return;

    const recentTasks = tasks
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);

    if (recentTasks.length === 0) {
        recentTasksList.innerHTML = '<p class="no-tasks">لا توجد مهام حديثة</p>';
        return;
    }

    recentTasksList.innerHTML = recentTasks.map(task => `
        <div class="task-item ${task.completed ? 'completed' : ''}" data-task-id="${task.id}">
            <div class="task-checkbox">
                <input type="checkbox" ${task.completed ? 'checked' : ''} 
                       onchange="toggleTask('${task.id}')">
            </div>
            <div class="task-content">
                <h4>${task.title}</h4>
                <p class="task-meta">
                    <span class="task-category ${task.category}">${getCategoryName(task.category)}</span>
                    <span class="task-priority ${task.priority}">${getPriorityName(task.priority)}</span>
                </p>
            </div>
        </div>
    `).join('');
}

function createWeeklyChart() {
    const ctx = document.getElementById('weekly-progress-chart');
    if (!ctx) return;

    const weekData = getWeeklyProgressData();
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'],
            datasets: [{
                label: 'المهام المكتملة',
                data: weekData.tasks,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'العادات المنجزة',
                data: weekData.habits,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0, 0, 0, 0.1)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function updateNotifications() {
    const notificationList = document.getElementById('notification-list');
    const notificationBadge = document.getElementById('notification-badge');
    
    const notifications = generateNotifications();
    
    if (notifications.length === 0) {
        notificationList.innerHTML = '<p class="no-notifications">لا توجد إشعارات جديدة</p>';
        notificationBadge.style.display = 'none';
        return;
    }

    notificationBadge.textContent = notifications.length;
    notificationBadge.style.display = 'block';

    notificationList.innerHTML = notifications.map(notification => `
        <div class="notification-item ${notification.type}">
            <div class="notification-icon">
                <i class="${notification.icon}"></i>
            </div>
            <div class="notification-content">
                <h4>${notification.title}</h4>
                <p>${notification.message}</p>
                <span class="notification-time">${notification.time}</span>
            </div>
        </div>
    `).join('');
}

function performGlobalSearch(query) {
    if (!query.trim()) return;

    const results = {
        tasks: tasks.filter(task => 
            task.title.toLowerCase().includes(query.toLowerCase()) ||
            task.description.toLowerCase().includes(query.toLowerCase())
        ),
        notes: notes.filter(note =>
            note.title.toLowerCase().includes(query.toLowerCase()) ||
            note.content.toLowerCase().includes(query.toLowerCase())
        ),
        projects: projects.filter(project =>
            project.name.toLowerCase().includes(query.toLowerCase()) ||
            project.description.toLowerCase().includes(query.toLowerCase())
        )
    };

    // عرض نتائج البحث (يمكن تطويرها لاحقًا)
    console.log('نتائج البحث:', results);
}

function performQuickAction(action) {
    switch(action) {
        case 'add-task':
            openTaskModal();
            break;
        case 'start-timer':
            switchSection('timer');
            break;
        case 'add-habit':
            switchSection('habits');
            break;
        case 'add-note':
            switchSection('notes');
            break;
    }
}

// إدارة المهام
function openTaskModal(taskId = null) {
    const modal = document.getElementById('modal-overlay');
    const modalTitle = document.getElementById('modal-title');
    const form = document.getElementById('task-form');
    
    if (taskId) {
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            modalTitle.textContent = 'تعديل المهمة';
            fillTaskForm(task);
        }
    } else {
        modalTitle.textContent = 'إضافة مهمة جديدة';
        form.reset();
    }
    
    modal.classList.add('show');
}

function closeTaskModal() {
    const modal = document.getElementById('modal-overlay');
    modal.classList.remove('show');
}

function fillTaskForm(task) {
    document.getElementById('task-title').value = task.title;
    document.getElementById('task-description').value = task.description;
    document.getElementById('task-category').value = task.category;
    document.getElementById('task-priority').value = task.priority;
    if (task.dueDate) {
        document.getElementById('task-due-date').value = task.dueDate;
    }
}

function saveTask() {
    const form = document.getElementById('task-form');
    const formData = new FormData(form);
    
    const task = {
        id: Date.now().toString(),
        title: document.getElementById('task-title').value,
        description: document.getElementById('task-description').value,
        category: document.getElementById('task-category').value,
        priority: document.getElementById('task-priority').value,
        dueDate: document.getElementById('task-due-date').value,
        completed: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };

    tasks.push(task);
    saveTasks();
    closeTaskModal();
    
    if (currentSection === 'tasks') {
        renderTasks();
    }
    
    updateDashboardStats();
    updateRecentTasks();
    
    showNotification('تم إضافة المهمة بنجاح', 'success');
}

function toggleTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        task.completed = !task.completed;
        task.updatedAt = new Date().toISOString();
        saveTasks();
        
        updateDashboardStats();
        updateRecentTasks();
        
        if (currentSection === 'tasks') {
            renderTasks();
        }
    }
}

function deleteTask(taskId) {
    if (confirm('هل أنت متأكد من حذف هذه المهمة؟')) {
        tasks = tasks.filter(t => t.id !== taskId);
        saveTasks();
        
        if (currentSection === 'tasks') {
            renderTasks();
        }
        
        updateDashboardStats();
        updateRecentTasks();
        
        showNotification('تم حذف المهمة بنجاح', 'success');
    }
}

function renderTasks() {
    const tasksContainer = document.getElementById('tasks-container');
    if (!tasksContainer) return;

    if (tasks.length === 0) {
        tasksContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-tasks"></i>
                <h3>لا توجد مهام</h3>
                <p>ابدأ بإضافة مهمة جديدة لتنظيم وقتك</p>
                <button class="btn btn-primary" onclick="openTaskModal()">
                    <i class="fas fa-plus"></i>
                    إضافة مهمة جديدة
                </button>
            </div>
        `;
        return;
    }

    tasksContainer.innerHTML = tasks.map(task => `
        <div class="task-card ${task.completed ? 'completed' : ''}" data-task-id="${task.id}">
            <div class="task-header">
                <div class="task-checkbox">
                    <input type="checkbox" ${task.completed ? 'checked' : ''} 
                           onchange="toggleTask('${task.id}')">
                </div>
                <h3 class="task-title">${task.title}</h3>
                <div class="task-actions">
                    <button class="task-action-btn" onclick="openTaskModal('${task.id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="task-action-btn delete" onclick="deleteTask('${task.id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
            
            ${task.description ? `<p class="task-description">${task.description}</p>` : ''}
            
            <div class="task-meta">
                <span class="task-category ${task.category}">${getCategoryName(task.category)}</span>
                <span class="task-priority ${task.priority}">${getPriorityName(task.priority)}</span>
                ${task.dueDate ? `<span class="task-due-date">
                    <i class="fas fa-calendar"></i>
                    ${formatDate(task.dueDate)}
                </span>` : ''}
            </div>
        </div>
    `).join('');
}

function filterTasks(filter) {
    let filteredTasks = tasks;
    
    switch(filter) {
        case 'pending':
            filteredTasks = tasks.filter(task => !task.completed);
            break;
        case 'completed':
            filteredTasks = tasks.filter(task => task.completed);
            break;
        case 'overdue':
            filteredTasks = tasks.filter(task => 
                !task.completed && task.dueDate && new Date(task.dueDate) < new Date()
            );
            break;
    }
    
    // عرض المهام المفلترة (تحديث مؤقت)
    console.log('المهام المفلترة:', filteredTasks);
}

function sortTasksBy(criteria) {
    switch(criteria) {
        case 'date':
            tasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            break;
        case 'priority':
            const priorityOrder = { high: 3, medium: 2, low: 1 };
            tasks.sort((a, b) => priorityOrder[b.priority] - priorityOrder[a.priority]);
            break;
        case 'category':
            tasks.sort((a, b) => a.category.localeCompare(b.category));
            break;
    }
    
    if (currentSection === 'tasks') {
        renderTasks();
    }
}

// وظائف مساعدة
function getTodayFocusTime() {
    // حساب وقت التركيز اليوم (مؤقت)
    return Math.floor(Math.random() * 120) + 30;
}

function getTodayCompletedHabits() {
    // حساب العادات المنجزة اليوم (مؤقت)
    return Math.floor(Math.random() * 5) + 1;
}

function calculateProductivityScore() {
    // حساب نسبة الإنتاجية (مؤقت)
    const completedTasks = tasks.filter(task => task.completed).length;
    const totalTasks = tasks.length;
    return totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
}

function getWeeklyProgressData() {
    // بيانات تقدم الأسبوع (مؤقتة)
    return {
        tasks: [3, 5, 4, 6, 8, 7, 5],
        habits: [2, 3, 4, 3, 5, 4, 3]
    };
}

function generateNotifications() {
    const notifications = [];
    
    // إشعارات المهام المتأخرة
    const overdueTasks = tasks.filter(task => 
        !task.completed && task.dueDate && new Date(task.dueDate) < new Date()
    );
    
    if (overdueTasks.length > 0) {
        notifications.push({
            type: 'warning',
            icon: 'fas fa-exclamation-triangle',
            title: 'مهام متأخرة',
            message: `لديك ${overdueTasks.length} مهام متأخرة`,
            time: 'الآن'
        });
    }
    
    // إشعارات أخرى يمكن إضافتها
    return notifications;
}

function getCategoryName(category) {
    const categories = {
        work: 'عمل',
        personal: 'شخصي',
        study: 'دراسة',
        health: 'صحة',
        other: 'أخرى'
    };
    return categories[category] || category;
}

function getPriorityName(priority) {
    const priorities = {
        low: 'منخفضة',
        medium: 'متوسطة',
        high: 'عالية'
    };
    return priorities[priority] || priority;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function showNotification(message, type = 'info') {
    // إنشاء إشعار مؤقت (يمكن تطويره لاحقًا)
    console.log(`${type}: ${message}`);
}

// وظائف الحفظ والتحميل
function saveTasks() {
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

function saveHabits() {
    localStorage.setItem('habits', JSON.stringify(habits));
}

function saveProjects() {
    localStorage.setItem('projects', JSON.stringify(projects));
}

function saveNotes() {
    localStorage.setItem('notes', JSON.stringify(notes));
}

function saveSettings() {
    localStorage.setItem('settings', JSON.stringify(settings));
}

// وظائف الأقسام الأخرى (ستطور لاحقًا)
function initializeTimer() {
    console.log('تهيئة مؤقت البومودورو...');
}

function renderHabits() {
    console.log('عرض العادات...');
}

function renderProjects() {
    console.log('عرض المشاريع...');
}

function renderStatistics() {
    console.log('عرض الإحصائيات...');
}

function renderNotes() {
    console.log('عرض المفكرة...');
}






// متغيرات مؤقت البومودورو
let timerState = {
    isRunning: false,
    isPaused: false,
    currentTime: 25 * 60, // 25 دقيقة بالثواني
    totalTime: 25 * 60,
    currentSession: 'work', // work, shortBreak, longBreak
    sessionsCompleted: 0,
    interval: null
};

let timerStats = JSON.parse(localStorage.getItem('timerStats')) || {
    sessionsToday: 0,
    totalFocusTime: 0,
    currentStreak: 0,
    lastSessionDate: null
};

// متغيرات العادات
let currentHabit = null;

// متغيرات المفكرة
let currentNote = null;

// إضافة مستمعي الأحداث للوظائف الجديدة
function setupAdditionalEventListeners() {
    // مؤقت البومودورو
    const startTimer = document.getElementById('start-timer');
    const pauseTimer = document.getElementById('pause-timer');
    const resetTimer = document.getElementById('reset-timer');
    const workDuration = document.getElementById('work-duration');
    const shortBreak = document.getElementById('short-break');
    const longBreak = document.getElementById('long-break');

    startTimer?.addEventListener('click', startPomodoroTimer);
    pauseTimer?.addEventListener('click', pausePomodoroTimer);
    resetTimer?.addEventListener('click', resetPomodoroTimer);
    
    workDuration?.addEventListener('change', updateTimerSettings);
    shortBreak?.addEventListener('change', updateTimerSettings);
    longBreak?.addEventListener('change', updateTimerSettings);

    // العادات
    const addHabitBtn = document.getElementById('add-habit-btn');
    addHabitBtn?.addEventListener('click', () => openHabitModal());

    // المشاريع
    const addProjectBtn = document.getElementById('add-project-btn');
    addProjectBtn?.addEventListener('click', () => openProjectModal());

    // المفكرة
    const addNoteBtn = document.getElementById('add-note-btn');
    const saveNote = document.getElementById('save-note');
    const deleteNote = document.getElementById('delete-note');
    const notesSearch = document.getElementById('notes-search');

    addNoteBtn?.addEventListener('click', createNewNote);
    saveNote?.addEventListener('click', saveCurrentNote);
    deleteNote?.addEventListener('click', deleteCurrentNote);
    notesSearch?.addEventListener('input', (e) => searchNotes(e.target.value));

    // الإحصائيات
    const statsPeriod = document.getElementById('stats-period');
    statsPeriod?.addEventListener('change', (e) => updateStatistics(e.target.value));
}

// وظائف مؤقت البومودورو
function startPomodoroTimer() {
    if (!timerState.isRunning) {
        timerState.isRunning = true;
        timerState.isPaused = false;
        
        timerState.interval = setInterval(() => {
            timerState.currentTime--;
            updateTimerDisplay();
            updateTimerProgress();
            
            if (timerState.currentTime <= 0) {
                completeTimerSession();
            }
        }, 1000);
        
        updateTimerButtons();
        playNotificationSound();
    }
}

function pausePomodoroTimer() {
    if (timerState.isRunning) {
        timerState.isRunning = false;
        timerState.isPaused = true;
        clearInterval(timerState.interval);
        updateTimerButtons();
    } else if (timerState.isPaused) {
        startPomodoroTimer();
    }
}

function resetPomodoroTimer() {
    timerState.isRunning = false;
    timerState.isPaused = false;
    clearInterval(timerState.interval);
    
    const workDuration = parseInt(document.getElementById('work-duration').value) || 25;
    timerState.currentTime = workDuration * 60;
    timerState.totalTime = workDuration * 60;
    timerState.currentSession = 'work';
    
    updateTimerDisplay();
    updateTimerProgress();
    updateTimerButtons();
}

function completeTimerSession() {
    clearInterval(timerState.interval);
    timerState.isRunning = false;
    timerState.isPaused = false;
    
    // تحديث الإحصائيات
    if (timerState.currentSession === 'work') {
        timerStats.sessionsToday++;
        timerStats.totalFocusTime += Math.floor(timerState.totalTime / 60);
        timerStats.currentStreak++;
        timerStats.lastSessionDate = new Date().toDateString();
        saveTimerStats();
    }
    
    // تحديد الجلسة التالية
    if (timerState.currentSession === 'work') {
        timerState.sessionsCompleted++;
        if (timerState.sessionsCompleted % 4 === 0) {
            startBreakSession('longBreak');
        } else {
            startBreakSession('shortBreak');
        }
    } else {
        startWorkSession();
    }
    
    updateTimerStats();
    playNotificationSound();
    showNotification('انتهت الجلسة!', 'success');
}

function startWorkSession() {
    const workDuration = parseInt(document.getElementById('work-duration').value) || 25;
    timerState.currentTime = workDuration * 60;
    timerState.totalTime = workDuration * 60;
    timerState.currentSession = 'work';
    
    updateTimerDisplay();
    updateTimerProgress();
    updateTimerButtons();
}

function startBreakSession(type) {
    const duration = type === 'longBreak' 
        ? parseInt(document.getElementById('long-break').value) || 15
        : parseInt(document.getElementById('short-break').value) || 5;
    
    timerState.currentTime = duration * 60;
    timerState.totalTime = duration * 60;
    timerState.currentSession = type;
    
    updateTimerDisplay();
    updateTimerProgress();
    updateTimerButtons();
}

function updateTimerDisplay() {
    const minutes = Math.floor(timerState.currentTime / 60);
    const seconds = timerState.currentTime % 60;
    const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    
    document.getElementById('timer-time').textContent = timeString;
    
    const labels = {
        work: 'جلسة عمل',
        shortBreak: 'راحة قصيرة',
        longBreak: 'راحة طويلة'
    };
    
    document.getElementById('timer-label').textContent = labels[timerState.currentSession];
}

function updateTimerProgress() {
    const progress = ((timerState.totalTime - timerState.currentTime) / timerState.totalTime) * 360;
    document.documentElement.style.setProperty('--progress-angle', `${progress}deg`);
}

function updateTimerButtons() {
    const startBtn = document.getElementById('start-timer');
    const pauseBtn = document.getElementById('pause-timer');
    
    if (timerState.isRunning) {
        startBtn.style.display = 'none';
        pauseBtn.innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
    } else if (timerState.isPaused) {
        startBtn.style.display = 'none';
        pauseBtn.innerHTML = '<i class="fas fa-play"></i> متابعة';
    } else {
        startBtn.style.display = 'flex';
        pauseBtn.innerHTML = '<i class="fas fa-pause"></i> إيقاف مؤقت';
    }
}

function updateTimerSettings() {
    if (!timerState.isRunning && !timerState.isPaused) {
        resetPomodoroTimer();
    }
}

function updateTimerStats() {
    document.getElementById('sessions-today').textContent = timerStats.sessionsToday;
    document.getElementById('total-focus-time').textContent = timerStats.totalFocusTime;
    document.getElementById('current-streak').textContent = timerStats.currentStreak;
}

function saveTimerStats() {
    localStorage.setItem('timerStats', JSON.stringify(timerStats));
}

// وظائف العادات
function renderHabits() {
    const habitsContainer = document.getElementById('habits-container');
    if (!habitsContainer) return;

    if (habits.length === 0) {
        habitsContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-chart-line"></i>
                <h3>لا توجد عادات</h3>
                <p>ابدأ بإضافة عادة جديدة لتتبع تقدمك</p>
                <button class="btn btn-primary" onclick="openHabitModal()">
                    <i class="fas fa-plus"></i>
                    إضافة عادة جديدة
                </button>
            </div>
        `;
        return;
    }

    habitsContainer.innerHTML = habits.map(habit => `
        <div class="habit-card" data-habit-id="${habit.id}">
            <div class="habit-header">
                <h3 class="habit-title">${habit.name}</h3>
                <span class="habit-streak">${habit.streak} يوم</span>
            </div>
            
            <div class="habit-progress">
                <div class="habit-progress-bar">
                    <div class="habit-progress-fill" style="width: ${calculateHabitProgress(habit)}%"></div>
                </div>
            </div>
            
            <div class="habit-days">
                ${generateHabitDays(habit)}
            </div>
            
            <div class="habit-actions">
                <button class="habit-btn complete" onclick="markHabitComplete('${habit.id}')">
                    <i class="fas fa-check"></i>
                    تم
                </button>
                <button class="habit-btn skip" onclick="skipHabit('${habit.id}')">
                    <i class="fas fa-times"></i>
                    تخطي
                </button>
            </div>
        </div>
    `).join('');
}

function openHabitModal(habitId = null) {
    // إنشاء نافذة منبثقة لإضافة/تعديل العادة
    const modalHTML = `
        <div class="modal-overlay show" id="habit-modal-overlay">
            <div class="modal" id="habit-modal">
                <div class="modal-header">
                    <h3>${habitId ? 'تعديل العادة' : 'إضافة عادة جديدة'}</h3>
                    <button class="modal-close" onclick="closeHabitModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="habit-form">
                        <div class="form-group">
                            <label for="habit-name">اسم العادة</label>
                            <input type="text" id="habit-name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="habit-description">الوصف</label>
                            <textarea id="habit-description" rows="3"></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="habit-frequency">التكرار</label>
                                <select id="habit-frequency">
                                    <option value="daily">يومي</option>
                                    <option value="weekly">أسبوعي</option>
                                    <option value="monthly">شهري</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="habit-target">الهدف</label>
                                <input type="number" id="habit-target" value="1" min="1">
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" class="btn btn-secondary" onclick="closeHabitModal()">إلغاء</button>
                            <button type="submit" class="btn btn-primary">حفظ العادة</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    document.getElementById('habit-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveHabit(habitId);
    });
}

function closeHabitModal() {
    const modal = document.getElementById('habit-modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function saveHabit(habitId = null) {
    const habit = {
        id: habitId || Date.now().toString(),
        name: document.getElementById('habit-name').value,
        description: document.getElementById('habit-description').value,
        frequency: document.getElementById('habit-frequency').value,
        target: parseInt(document.getElementById('habit-target').value),
        streak: 0,
        completedDates: [],
        createdAt: habitId ? habits.find(h => h.id === habitId).createdAt : new Date().toISOString()
    };

    if (habitId) {
        const index = habits.findIndex(h => h.id === habitId);
        habits[index] = { ...habits[index], ...habit };
    } else {
        habits.push(habit);
    }

    saveHabits();
    closeHabitModal();
    renderHabits();
    showNotification('تم حفظ العادة بنجاح', 'success');
}

function markHabitComplete(habitId) {
    const habit = habits.find(h => h.id === habitId);
    if (habit) {
        const today = new Date().toDateString();
        if (!habit.completedDates.includes(today)) {
            habit.completedDates.push(today);
            habit.streak++;
            saveHabits();
            renderHabits();
            updateDashboardStats();
            showNotification('أحسنت! تم تسجيل العادة', 'success');
        }
    }
}

function skipHabit(habitId) {
    const habit = habits.find(h => h.id === habitId);
    if (habit) {
        habit.streak = 0;
        saveHabits();
        renderHabits();
        showNotification('تم تخطي العادة', 'info');
    }
}

function calculateHabitProgress(habit) {
    const today = new Date();
    const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
    const completedThisWeek = habit.completedDates.filter(date => 
        new Date(date) >= weekStart
    ).length;
    
    return Math.min((completedThisWeek / 7) * 100, 100);
}

function generateHabitDays(habit) {
    const days = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];
    const today = new Date();
    const weekStart = new Date(today.setDate(today.getDate() - today.getDay()));
    
    return days.map((day, index) => {
        const date = new Date(weekStart);
        date.setDate(weekStart.getDate() + index);
        const dateString = date.toDateString();
        const isCompleted = habit.completedDates.includes(dateString);
        const isToday = dateString === new Date().toDateString();
        
        return `
            <div class="habit-day ${isCompleted ? 'completed' : ''} ${isToday ? 'today' : ''}">
                ${day}
            </div>
        `;
    }).join('');
}

// وظائف المشاريع
function renderProjects() {
    const projectsContainer = document.getElementById('projects-container');
    if (!projectsContainer) return;

    if (projects.length === 0) {
        projectsContainer.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-folder-open"></i>
                <h3>لا توجد مشاريع</h3>
                <p>ابدأ بإضافة مشروع جديد لتنظيم مهامك</p>
                <button class="btn btn-primary" onclick="openProjectModal()">
                    <i class="fas fa-plus"></i>
                    إضافة مشروع جديد
                </button>
            </div>
        `;
        return;
    }

    projectsContainer.innerHTML = projects.map(project => `
        <div class="project-card" data-project-id="${project.id}">
            <div class="project-header">
                <div>
                    <h3 class="project-title">${project.name}</h3>
                    <p class="project-description">${project.description}</p>
                </div>
                <span class="project-status ${project.status}">${getProjectStatusName(project.status)}</span>
            </div>
            
            <div class="project-progress">
                <div class="project-progress-header">
                    <span class="project-progress-label">التقدم</span>
                    <span class="project-progress-percentage">${calculateProjectProgress(project)}%</span>
                </div>
                <div class="project-progress-bar">
                    <div class="project-progress-fill" style="width: ${calculateProjectProgress(project)}%"></div>
                </div>
            </div>
            
            <div class="project-meta">
                <span>المهام: ${project.tasks?.length || 0}</span>
                <span>الموعد النهائي: ${project.dueDate ? formatDate(project.dueDate) : 'غير محدد'}</span>
            </div>
        </div>
    `).join('');
}

function openProjectModal(projectId = null) {
    // إنشاء نافذة منبثقة لإضافة/تعديل المشروع
    const modalHTML = `
        <div class="modal-overlay show" id="project-modal-overlay">
            <div class="modal" id="project-modal">
                <div class="modal-header">
                    <h3>${projectId ? 'تعديل المشروع' : 'إضافة مشروع جديد'}</h3>
                    <button class="modal-close" onclick="closeProjectModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="project-form">
                        <div class="form-group">
                            <label for="project-name">اسم المشروع</label>
                            <input type="text" id="project-name" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="project-description">الوصف</label>
                            <textarea id="project-description" rows="3"></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="project-status">الحالة</label>
                                <select id="project-status">
                                    <option value="active">نشط</option>
                                    <option value="paused">متوقف</option>
                                    <option value="completed">مكتمل</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="project-due-date">الموعد النهائي</label>
                                <input type="date" id="project-due-date">
                            </div>
                        </div>
                        
                        <div class="form-actions">
                            <button type="button" class="btn btn-secondary" onclick="closeProjectModal()">إلغاء</button>
                            <button type="submit" class="btn btn-primary">حفظ المشروع</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    document.getElementById('project-form').addEventListener('submit', (e) => {
        e.preventDefault();
        saveProject(projectId);
    });
}

function closeProjectModal() {
    const modal = document.getElementById('project-modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function saveProject(projectId = null) {
    const project = {
        id: projectId || Date.now().toString(),
        name: document.getElementById('project-name').value,
        description: document.getElementById('project-description').value,
        status: document.getElementById('project-status').value,
        dueDate: document.getElementById('project-due-date').value,
        tasks: projectId ? projects.find(p => p.id === projectId).tasks || [] : [],
        createdAt: projectId ? projects.find(p => p.id === projectId).createdAt : new Date().toISOString()
    };

    if (projectId) {
        const index = projects.findIndex(p => p.id === projectId);
        projects[index] = { ...projects[index], ...project };
    } else {
        projects.push(project);
    }

    saveProjects();
    closeProjectModal();
    renderProjects();
    showNotification('تم حفظ المشروع بنجاح', 'success');
}

function calculateProjectProgress(project) {
    if (!project.tasks || project.tasks.length === 0) return 0;
    const completedTasks = project.tasks.filter(task => task.completed).length;
    return Math.round((completedTasks / project.tasks.length) * 100);
}

function getProjectStatusName(status) {
    const statuses = {
        active: 'نشط',
        paused: 'متوقف',
        completed: 'مكتمل'
    };
    return statuses[status] || status;
}

// وظائف المفكرة
function renderNotes() {
    const notesList = document.getElementById('notes-list');
    if (!notesList) return;

    if (notes.length === 0) {
        notesList.innerHTML = `
            <div class="empty-state">
                <p>لا توجد ملاحظات</p>
                <button class="btn btn-primary" onclick="createNewNote()">
                    إضافة ملاحظة جديدة
                </button>
            </div>
        `;
        return;
    }

    notesList.innerHTML = notes.map(note => `
        <div class="note-item ${currentNote?.id === note.id ? 'active' : ''}" 
             onclick="selectNote('${note.id}')">
            <div class="note-item-title">${note.title || 'ملاحظة بدون عنوان'}</div>
            <div class="note-item-preview">${note.content.substring(0, 50)}...</div>
        </div>
    `).join('');
}

function createNewNote() {
    const newNote = {
        id: Date.now().toString(),
        title: '',
        content: '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };

    notes.unshift(newNote);
    currentNote = newNote;
    
    document.getElementById('note-title').value = '';
    document.getElementById('note-content').value = '';
    
    renderNotes();
    saveNotes();
}

function selectNote(noteId) {
    currentNote = notes.find(note => note.id === noteId);
    if (currentNote) {
        document.getElementById('note-title').value = currentNote.title;
        document.getElementById('note-content').value = currentNote.content;
        renderNotes();
    }
}

function saveCurrentNote() {
    if (!currentNote) return;

    currentNote.title = document.getElementById('note-title').value;
    currentNote.content = document.getElementById('note-content').value;
    currentNote.updatedAt = new Date().toISOString();

    saveNotes();
    renderNotes();
    showNotification('تم حفظ الملاحظة', 'success');
}

function deleteCurrentNote() {
    if (!currentNote) return;

    if (confirm('هل أنت متأكد من حذف هذه الملاحظة؟')) {
        notes = notes.filter(note => note.id !== currentNote.id);
        currentNote = null;
        
        document.getElementById('note-title').value = '';
        document.getElementById('note-content').value = '';
        
        saveNotes();
        renderNotes();
        showNotification('تم حذف الملاحظة', 'success');
    }
}

function searchNotes(query) {
    const filteredNotes = notes.filter(note =>
        note.title.toLowerCase().includes(query.toLowerCase()) ||
        note.content.toLowerCase().includes(query.toLowerCase())
    );

    const notesList = document.getElementById('notes-list');
    notesList.innerHTML = filteredNotes.map(note => `
        <div class="note-item ${currentNote?.id === note.id ? 'active' : ''}" 
             onclick="selectNote('${note.id}')">
            <div class="note-item-title">${note.title || 'ملاحظة بدون عنوان'}</div>
            <div class="note-item-preview">${note.content.substring(0, 50)}...</div>
        </div>
    `).join('');
}

// وظائف الإحصائيات
function renderStatistics() {
    createTasksProductivityChart();
    createHabitsProgressChart();
    createTimeDistributionChart();
    createProjectsProgressChart();
}

function createTasksProductivityChart() {
    const ctx = document.getElementById('tasks-productivity-chart');
    if (!ctx) return;

    const data = getTasksProductivityData();
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'],
            datasets: [{
                label: 'المهام المكتملة',
                data: data,
                backgroundColor: 'rgba(37, 99, 235, 0.8)',
                borderColor: '#2563eb',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function createHabitsProgressChart() {
    const ctx = document.getElementById('habits-progress-chart');
    if (!ctx) return;

    const data = getHabitsProgressData();
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'العادات المنجزة',
                data: data.values,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function createTimeDistributionChart() {
    const ctx = document.getElementById('time-distribution-chart');
    if (!ctx) return;

    const data = getTimeDistributionData();
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.labels,
            datasets: [{
                data: data.values,
                backgroundColor: [
                    '#2563eb',
                    '#10b981',
                    '#f59e0b',
                    '#ef4444',
                    '#8b5cf6'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

function createProjectsProgressChart() {
    const ctx = document.getElementById('projects-progress-chart');
    if (!ctx) return;

    const data = getProjectsProgressData();
    
    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'تقدم المشاريع',
                data: data.values,
                borderColor: '#2563eb',
                backgroundColor: 'rgba(37, 99, 235, 0.2)',
                pointBackgroundColor: '#2563eb'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                r: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

function updateStatistics(period) {
    // تحديث الإحصائيات حسب الفترة المحددة
    renderStatistics();
}

// وظائف مساعدة للبيانات
function getTasksProductivityData() {
    // بيانات مؤقتة للمهام المكتملة
    return [3, 5, 4, 6, 8, 7, 5];
}

function getHabitsProgressData() {
    return {
        labels: ['الأسبوع 1', 'الأسبوع 2', 'الأسبوع 3', 'الأسبوع 4'],
        values: [60, 75, 80, 85]
    };
}

function getTimeDistributionData() {
    return {
        labels: ['عمل', 'دراسة', 'رياضة', 'ترفيه', 'أخرى'],
        values: [40, 25, 15, 15, 5]
    };
}

function getProjectsProgressData() {
    return {
        labels: projects.slice(0, 5).map(p => p.name),
        values: projects.slice(0, 5).map(p => calculateProjectProgress(p))
    };
}

// وظائف الصوت
function playNotificationSound() {
    // إنشاء صوت إشعار بسيط
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
}

// تحديث الدالة الرئيسية لتشمل المستمعين الجدد
const originalSetupEventListeners = setupEventListeners;
setupEventListeners = function() {
    originalSetupEventListeners();
    setupAdditionalEventListeners();
};

// تحديث دالة التهيئة
const originalInitializeApp = initializeApp;
initializeApp = function() {
    // إخفاء شاشة التحميل
    setTimeout(() => {
        document.getElementById('loading-screen').classList.add('hidden');
        document.querySelector('.app-container').classList.add('loaded');
    }, 1500);

    // تطبيق الثيم المحفوظ
    applyTheme(settings.theme);

    // إعداد مستمعي الأحداث
    setupEventListeners();
    setupAdditionalEventListeners();

    // تحديث الإحصائيات
    updateDashboardStats();

    // تحديث المهام الحديثة
    updateRecentTasks();

    // إنشاء الرسم البياني
    createWeeklyChart();

    // تحديث الإشعارات
    updateNotifications();
    
    // تهيئة الإحصائيات الإضافية
    updateTimerStats();
    
    // تحقق من تاريخ آخر جلسة لإعادة تعيين الإحصائيات اليومية
    const today = new Date().toDateString();
    if (timerStats.lastSessionDate !== today) {
        timerStats.sessionsToday = 0;
        saveTimerStats();
        updateTimerStats();
    }
};

